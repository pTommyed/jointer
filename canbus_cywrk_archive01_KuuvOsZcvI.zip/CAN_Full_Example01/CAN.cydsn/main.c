#include <project.h>
#define DATALENGTH 0x08 /* size of data to be transmitted */

CAN_TX_MSG messageRPM;
CAN_DATA_BYTES_MSG Data;

float rpm=1000;

void buffer_append_int32(uint8_t* buffer, int32_t number, int32_t *index) {
    buffer[(*index)++] = number >> 24;
    buffer[(*index)++] = number >> 16;
    buffer[(*index)++] = number >> 8;
    buffer[(*index)++] = number;
}

typedef enum {
    CAN_PACKET_SET_DUTY = 0,
    CAN_PACKET_SET_CURRENT,
    CAN_PACKET_SET_CURRENT_BRAKE,
    CAN_PACKET_SET_RPM,
    CAN_PACKET_SET_POS,
    CAN_PACKET_FILL_RX_BUFFER,
    CAN_PACKET_FILL_RX_BUFFER_LONG,
    CAN_PACKET_PROCESS_RX_BUFFER,
    CAN_PACKET_PROCESS_SHORT_BUFFER,
    CAN_PACKET_STATUS
} CAN_PACKET_ID;

void can_set_rpm(uint8_t controller_id, float rpm) {   
    uint8 bIndex;
    int32_t send_index = 0;
    uint8_t buffer[4];
    uint8 MESSAGE[8];
    messageRPM.id =controller_id | ((uint32_t)CAN_PACKET_SET_RPM << 8);
    
    buffer_append_int32(buffer, (int32_t)rpm, &send_index);
    MESSAGE[0]=buffer[0];MESSAGE[1]=buffer[1];MESSAGE[2]=buffer[2];MESSAGE[3]=buffer[3];
    
    //MESSAGE [4-7]={0x00,0x00,0x00,0x00};//define 8 bytes of data
    for(bIndex=0;bIndex<DATALENGTH;bIndex++){
        Data.byte[bIndex] = MESSAGE[bIndex]; /* move data to the structure*/
    }
    messageRPM.msg = &Data;  
    CAN_SendMsg(&messageRPM);
}
int main(){
    CYGlobalIntEnable; /*enable global interrupts*/  
    messageRPM.id = 0x301; /*write the value of ID to the structure*/
    messageRPM.rtr = 0; /*write the value of RTR to the structure*/
    messageRPM.ide = 1; /*write the value of IDE to the structure*/
    messageRPM.dlc = DATALENGTH; /*write the value of DLC to the structure*/
    messageRPM.irq = 1; /*write the value of IRQ to the structure*/
    messageRPM.msg = &Data; /* write address of structure that represents data*/
    
    CAN_Init(); /* initialize CAN node */
    CAN_Start(); /* start CAN node */
    CyDelay(400);
    
    while (1)
    {     
        can_set_rpm(1,1000);
        CyDelay(150);        
    }
}

